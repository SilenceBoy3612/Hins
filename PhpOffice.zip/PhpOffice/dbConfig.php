<?php

//数据库基础配置
$phpexcel=array(
    'host'=>'localhost',
    'username'=>'root',
    'password'=>'1234',
    'dbname'=>"dbms"
);
?>